﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assets.Scripts.Quests
{
    public static class QuestChainIds
    {
        public static string Test1 { get; } = "test1";
        public static string Test2 { get; } = "test2";
        public static string Aboba { get; } = "ABOBA";
    }
}
